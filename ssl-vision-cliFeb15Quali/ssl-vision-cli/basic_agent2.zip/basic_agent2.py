# basic_agent2.py
from agent_behaviours import go_towards_ball
from agent_behaviours import follow_agent
from agent import agent
import math
import numpy as np
from prm_planner import PRMPlanning

class BasicAgent_Graph(agent):
    def __init__(self, id, world2robot_fn=None):
        super().__init__(id)
        # To do: find x and y of self
        # Store the transformation function
        self.world2robot_fn = world2robot_fn

    def act(self, frame):
        if "ball" in frame["detection"]:
            ball_position = np.array([frame['detection']['ball']['x'], frame['detection']['ball']['y']])
            robot_data = frame["detection"]["robots_blue"][self.id]

        detection = frame["detection"]
        yellow_robots = detection["robots_yellow"]
        blue_robots = detection["robots_blue"]

        obstacles = []

        for yellow_robot in yellow_robots:
            x = yellow_robot["x"]
            y = yellow_robot["y"]
            obstacles.append([x, y])
        for blue_robot in blue_robots:
            if not blue_robot["robot_id"] == self.id:
                x = blue_robot["x"]
                y = blue_robot["y"]
                obstacles.append([x, y])
            
        num_samples = 15
        radius = 1
        

        
        prm = PRMPlanning()
        graph = prm.populate_graph(obstacles, num_samples, radius)
        
        path = prm.find_path(graph, self.position, ball_position) # print this and expriment
# (self, obstacles, num_samples, radius):
                



        return self.id, vx, vy, vz
